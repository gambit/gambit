Gambit #912 technical evidence candidate, not proof of full make check, not proof of bounty acceptance.
Open REPORT.md, evidence_checks.json, and SPONSOR_INQUIRY_DRAFT.txt.
Do NOT post without owner approval and sponsor confirmation.
Only isolated_core.patch is included: experimental NEED_REHASH draft deliberately excluded.
Review before sharing.
